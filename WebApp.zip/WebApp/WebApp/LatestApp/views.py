from django.http import HttpResponse
from django.shortcuts import render

from .forms import PharmaForm

from .models import PharmaUser

import random
import smtplib, ssl

# Create your views here.
def index(request):
    return render(request, 'App/index.html')

def contactus(request):
    return render(request, 'App/contactus.html')

def pharma(request):
    return render(request, 'App/pharma.html')

def ihwc(request):
    return render(request, 'App/ihwc.html')

def emergency(request):
    return render(request, 'App/emergency.html')

def about(request):
    return render(request, 'App/about.html')

def HowItWorks(request):
    return render(request, 'App/HowItWorks.html')

def check(request):
    if request.method == "POST":  
        code = request.POST.get('code')

        user = PharmaUser.objects.filter(verifyCode=code).first()

        if user:
            return render(request, 'App/success.html')
        else:
            return render(request, 'App/failed.html')

def checkLogin(request):
    if request.method == "POST":  
        user = request.POST.get('email')
        passs = request.POST.get('password')

        user = PharmaUser.objects.filter(email=user, password=passs).first()

        if user:
            return render(request, 'App/index.html')
        else:
            return render(request, 'App/login.html')

def failed(request):
    return render(request, 'App/verify.html')

def login(request):
    return render(request, 'App/login.html')

def signup(request):
    return render(request, 'App/signup.html')

def verify(request):
    if request.method == "POST":  
        form = PharmaForm(request.POST)  
        print(form.is_valid())
        if form.is_valid(): 
            try:

                number = random.randint(1000,9999)

                SUBJECT = 'Verification Email'

                TEXT = "Please Enter The Following Verification Code: " + str(number)

                message = 'Subject: {}\n\n{}'.format(SUBJECT, TEXT)

                context = ssl.create_default_context()

                print('TESST 12345 CHECK')

                #https://myaccount.google.com/lesssecureapps, visit this site and turn on less secure app for email sending and receiving 
                with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
                    server.login('uiachemist@gmail.com', 'Chemist@Uia') #gmail email, password
                    server.sendmail('uiachemist@gmail.com', request.POST.get('email'), message) #email of sender, receiver

                form.instance.verifyCode = number
                form.save() 
                return render(request, 'App/verify.html')
            except:  
                pass  
    else:  
        form = PharmaForm()  
from django import forms  
from .models import PharmaUser

class PharmaForm(forms.ModelForm):  
    class Meta:  
        model = PharmaUser  
        fields = [
            "fname",
            "lname",
            "gender",
            "matricNumber",
            "email",
            "password",
            "phone"
        ]
from django.db import models

# Create your models here.
class PharmaUser(models.Model):
    fname = models.CharField(max_length=30)
    lname = models.CharField(max_length=30, null=True)
    gender = models.CharField(max_length=10, null=True)
    matricNumber = models.IntegerField()
    email = models.EmailField(max_length=50)
    password = models.CharField(max_length=50)
    phone = models.CharField(max_length=20)
    verifyCode = models.CharField(max_length=5)

    def __str__(self):
        return self.email
from django.apps import AppConfig


class LatestappConfig(AppConfig):
    name = 'LatestApp'
